Compilation command:
g++ -std=c++11 -o dndhelp *.cpp
Run:
./dndhelp